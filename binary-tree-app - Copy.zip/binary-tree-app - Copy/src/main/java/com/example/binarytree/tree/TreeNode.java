public class TreeNode {
    public int value;
    public TreeNode left, right;

    public TreeNode(int val) {
        this.value = val;
    }
}
