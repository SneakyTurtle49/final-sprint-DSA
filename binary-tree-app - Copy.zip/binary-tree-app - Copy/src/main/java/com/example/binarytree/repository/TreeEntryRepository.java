@Repository
public interface TreeEntryRepository extends JpaRepository<TreeEntry, Long> {}
